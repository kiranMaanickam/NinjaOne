package test1;

import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.AfterClass;
 
public class NewTest {
	public WebDriver driver;
	  @Test
	  public void openMyBlog() {
//		  driver.get("http://localhost:3001");
		  driver.navigate().to("http://localhost:3001");
	  }
	  
	  @BeforeClass
	  public void beforeClass() {
	  
		  System.setProperty("webdriver.chrome.driver", "C:\\Users\\kiran\\Downloads\\chromedriver_win32\\chromedriver.exe");
		  driver = new ChromeDriver();
	  
	  }
	 
	  @AfterClass
	  public void afterClass() {
		  driver.quit();
	  }

}
