package utility;

public class Constant {
    public static final String URL = "http://localhost:3001";

}
